from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from models import db, User, ChitFund, ChitFundRegistration, OTPLog
from datetime import datetime
from sqlalchemy import func

admin = Blueprint('admin', __name__, url_prefix='/admin')

@admin.route('/')
def dashboard():
    """Admin dashboard"""
    # Get statistics
    total_users = User.query.count()
    total_registrations = ChitFundRegistration.query.count()
    pending_registrations = ChitFundRegistration.query.filter_by(status='pending').count()
    total_funds = ChitFund.query.count()
    
    # Recent registrations
    recent_registrations = ChitFundRegistration.query.order_by(
        ChitFundRegistration.registration_date.desc()
    ).limit(10).all()
    
    # Registration stats by fund
    fund_stats = db.session.query(
        ChitFund.name,
        func.count(ChitFundRegistration.id).label('registration_count')
    ).outerjoin(ChitFundRegistration).group_by(ChitFund.id, ChitFund.name).all()
    
    stats = {
        'total_users': total_users,
        'total_registrations': total_registrations,
        'pending_registrations': pending_registrations,
        'total_funds': total_funds
    }
    
    return render_template('admin/dashboard.html', 
                         stats=stats,
                         recent_registrations=recent_registrations,
                         fund_stats=fund_stats)

@admin.route('/users')
def users():
    """View all users"""
    page = request.args.get('page', 1, type=int)
    users = User.query.paginate(
        page=page, per_page=20, error_out=False
    )
    return render_template('admin/users.html', users=users)

@admin.route('/registrations')
def registrations():
    """View all registrations"""
    page = request.args.get('page', 1, type=int)
    status_filter = request.args.get('status', 'all')
    
    query = ChitFundRegistration.query
    if status_filter != 'all':
        query = query.filter_by(status=status_filter)
    
    registrations = query.order_by(
        ChitFundRegistration.registration_date.desc()
    ).paginate(page=page, per_page=20, error_out=False)
    
    return render_template('admin/registrations.html', 
                         registrations=registrations,
                         status_filter=status_filter)

@admin.route('/registration/<int:registration_id>/update-status', methods=['POST'])
def update_registration_status(registration_id):
    """Update registration status"""
    registration = ChitFundRegistration.query.get_or_404(registration_id)
    new_status = request.form.get('status')
    
    if new_status in ['pending', 'approved', 'rejected']:
        registration.status = new_status
        db.session.commit()
        flash(f'Registration status updated to {new_status}', 'success')
    else:
        flash('Invalid status', 'error')
    
    return redirect(url_for('admin.registrations'))

@admin.route('/funds')
def funds():
    """View all chit funds"""
    funds = ChitFund.query.all()
    return render_template('admin/funds.html', funds=funds)

@admin.route('/fund/<int:fund_id>/toggle-active', methods=['POST'])
def toggle_fund_active(fund_id):
    """Toggle fund active status"""
    fund = ChitFund.query.get_or_404(fund_id)
    fund.is_active = not fund.is_active
    db.session.commit()
    
    status = 'activated' if fund.is_active else 'deactivated'
    flash(f'Fund {fund.name} has been {status}', 'success')
    
    return redirect(url_for('admin.funds'))