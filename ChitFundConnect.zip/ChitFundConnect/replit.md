# Chit Fund App

## Overview

A Flask-based web application for managing chit fund services. The app provides a user-friendly interface for selecting and registering for various chit fund schemes. It features phone number-based authentication with OTP verification and a responsive design optimized for Indian users.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

### January 11, 2025
- Added PostgreSQL database integration with complete data persistence
- Created user management system with OTP verification logging
- Added user dashboard showing registration history and status
- Created admin panel for managing users, registrations, and chit funds
- Updated color palette to traditional Indian colors:
  - Background: Ivory Sand (#F8F1E5)
  - Primary: Maroon Red/Sindoor (#7B2E2E)
  - Accent: Golden Yellow (#E0B341)
  - Buttons: Indigo Traditional (#3C4C70)
  - Text: Charcoal Gray (#2E2E2E)
  - Success: Neem Leaf Green (#4B814B)
  - Error: Brick Clay Red (#B14623)

## System Architecture

### Frontend Architecture
- **Template Engine**: Jinja2 templates with Flask
- **CSS Framework**: Bootstrap 5.3.0 for responsive design
- **JavaScript**: Vanilla JS for client-side interactions
- **UI Components**: Font Awesome icons for visual elements
- **Design Pattern**: Mobile-first responsive design with Indian color scheme

### Backend Architecture
- **Framework**: Flask (Python web framework)
- **Session Management**: Filesystem-based sessions
- **Authentication**: Phone number + OTP verification system
- **Data Storage**: In-memory Python data structures (hardcoded chit fund data)
- **WSGI**: ProxyFix middleware for deployment behind reverse proxy

## Key Components

### Authentication System
- **Phone Number Input**: 10-digit Indian mobile number validation
- **OTP Verification**: Demo mode accepting any 4-digit code
- **Session Management**: Flask sessions for maintaining user state

### Chit Fund Selection
- **Predefined Schemes**: Three tiers (₹50K, ₹100K, ₹200K)
- **Scheme Details**: Amount, duration, members, renewal cycle
- **User Interface**: Card-based selection with detailed information

### User Flow
1. Login with phone number
2. OTP verification
3. Chit fund selection
4. Success confirmation

## Data Flow

1. **User Registration**: Phone number → OTP verification → Session creation
2. **Fund Selection**: Browse available funds → Select preferred scheme → Registration confirmation
3. **Session Management**: User state maintained throughout the application flow

## External Dependencies

### Frontend Libraries
- **Bootstrap 5.3.0**: UI framework from CDN
- **Font Awesome 6.4.0**: Icon library from CDN

### Python Packages
- **Flask**: Web framework
- **Werkzeug**: WSGI utilities (ProxyFix middleware)

### Environment Variables
- **SESSION_SECRET**: Session encryption key (defaults to demo key)

## Deployment Strategy

### Development Configuration
- **Host**: 0.0.0.0 (all interfaces)
- **Port**: 5000
- **Debug Mode**: Enabled
- **Logging**: Debug level logging configured

### Production Considerations
- **Session Storage**: Currently filesystem-based, may need Redis/database for scaling
- **Environment Variables**: Proper secret key management required
- **WSGI Server**: Ready for deployment with ProxyFix middleware
- **Static Files**: Served through Flask in development, should use CDN/static server in production

### Current Limitations
- **No Database**: All data stored in memory (chit fund schemes hardcoded)
- **No Real OTP**: Demo mode only - integration with SMS service needed
- **No User Persistence**: User data not stored permanently
- **No Payment Integration**: Financial transactions not implemented

### Recommended Enhancements
- Add database integration for user and transaction data
- Implement real OTP service (SMS gateway)
- Add payment gateway integration
- Implement user dashboard and transaction history
- Add admin panel for managing chit funds
- Add data persistence and backup strategies