import os
import logging
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.middleware.proxy_fix import ProxyFix
from models import db, User, ChitFund, ChitFundRegistration, OTPLog
from admin import admin

# Configure logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "demo-secret-key-for-chit-fund")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configure database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize database
db.init_app(app)

# Register blueprints
app.register_blueprint(admin)

# Configure session
app.config['SESSION_TYPE'] = 'filesystem'

# Initialize database and create tables
with app.app_context():
    db.create_all()
    
    # Check if chit funds exist, if not create them
    if ChitFund.query.count() == 0:
        chit_funds = [
            ChitFund(
                name='₹50,000 Basic Saving',
                amount=50000,
                duration='15 months',
                members=15,
                renewal_cycle='4 months',
                description='Perfect for beginners to start their savings journey'
            ),
            ChitFund(
                name='₹1,00,000 Moderate Saving',
                amount=100000,
                duration='15 months',
                members=15,
                renewal_cycle='4 months',
                description='Ideal for medium-term financial goals'
            ),
            ChitFund(
                name='₹2,00,000 Super Saving',
                amount=200000,
                duration='15 months',
                members=15,
                renewal_cycle='4 months',
                description='Best for high-value investments and large expenses'
            )
        ]
        
        for fund in chit_funds:
            db.session.add(fund)
        
        db.session.commit()
        print("Created initial chit funds in database")

@app.route('/')
def index():
    """Home page - redirect to login if not authenticated"""
    if 'phone_number' in session and session.get('otp_verified'):
        return redirect(url_for('chit_funds'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page with phone number input"""
    if request.method == 'POST':
        phone_number = request.form.get('phone_number', '').strip()
        
        # Validate phone number (Indian format)
        if not phone_number:
            flash('Please enter your phone number', 'error')
            return render_template('login.html')
        
        # Remove any non-digit characters
        phone_digits = ''.join(filter(str.isdigit, phone_number))
        
        # Check if it's a valid Indian phone number (10 digits)
        if len(phone_digits) != 10 or not phone_digits.startswith(('6', '7', '8', '9')):
            flash('Please enter a valid 10-digit Indian mobile number', 'error')
            return render_template('login.html')
        
        # Check if user exists, if not create them
        user = User.query.filter_by(phone_number=phone_digits).first()
        if not user:
            user = User(phone_number=phone_digits)
            db.session.add(user)
            db.session.commit()
        else:
            # Update last login
            user.last_login = datetime.utcnow()
            db.session.commit()
        
        # Store phone number in session and redirect to OTP
        session['phone_number'] = phone_digits
        session['user_id'] = user.id
        session['otp_verified'] = False
        
        # Generate and log OTP (for demo purposes)
        demo_otp = "1234"  # In production, generate random OTP
        otp_log = OTPLog(phone_number=phone_digits, otp_sent=demo_otp)
        db.session.add(otp_log)
        db.session.commit()
        
        print(f"Demo OTP sent to {phone_digits}: Any 4-digit code will work")
        
        return redirect(url_for('otp_verify'))
    
    return render_template('login.html')

@app.route('/otp', methods=['GET', 'POST'])
def otp_verify():
    """OTP verification page"""
    if 'phone_number' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        otp = request.form.get('otp', '').strip()
        
        # Validate OTP format
        if not otp or len(otp) != 4 or not otp.isdigit():
            flash('Please enter a valid 4-digit OTP', 'error')
            return render_template('otp.html', phone_number=session['phone_number'])
        
        # For demo - accept any 4-digit OTP
        # In production, verify against the OTP sent
        session['otp_verified'] = True
        
        # Update OTP log as verified
        otp_log = OTPLog.query.filter_by(
            phone_number=session['phone_number']
        ).order_by(OTPLog.created_at.desc()).first()
        
        if otp_log:
            otp_log.verified = True
            otp_log.verified_at = datetime.utcnow()
            db.session.commit()
        
        flash('Login successful!', 'success')
        
        print(f"Demo: User {session['phone_number']} logged in successfully with OTP: {otp}")
        
        return redirect(url_for('chit_funds'))
    
    return render_template('otp.html', phone_number=session['phone_number'])

@app.route('/chit-funds')
def chit_funds():
    """Display available chit funds"""
    if 'phone_number' not in session or not session.get('otp_verified'):
        return redirect(url_for('login'))
    
    # Get active chit funds from database
    active_funds = ChitFund.query.filter_by(is_active=True).all()
    
    return render_template('chit_funds.html', chit_funds=active_funds)

@app.route('/select-fund', methods=['POST'])
def select_fund():
    """Handle chit fund selection"""
    if 'phone_number' not in session or not session.get('otp_verified'):
        return redirect(url_for('login'))
    
    fund_id = request.form.get('fund_id')
    if not fund_id:
        flash('Please select a chit fund', 'error')
        return redirect(url_for('chit_funds'))
    
    try:
        fund_id = int(fund_id)
        selected_fund = ChitFund.query.get(fund_id)
        
        if not selected_fund:
            flash('Invalid chit fund selection', 'error')
            return redirect(url_for('chit_funds'))
        
        phone_number = session['phone_number']
        user_id = session['user_id']
        
        # Check if user already registered for this fund
        existing_registration = ChitFundRegistration.query.filter_by(
            user_id=user_id, 
            chit_fund_id=fund_id
        ).first()
        
        if existing_registration:
            flash('You have already registered for this chit fund!', 'warning')
            return redirect(url_for('chit_funds'))
        
        # Create new registration
        registration = ChitFundRegistration(
            user_id=user_id,
            chit_fund_id=fund_id,
            whatsapp_sent=True  # Mark as sent since we're simulating
        )
        db.session.add(registration)
        db.session.commit()
        
        # Simulate WhatsApp message sending
        whatsapp_message = f"""
🎉 New Chit Fund Registration!
📱 Phone: +91{phone_number}
💰 Selected Fund: {selected_fund.name}
📅 Duration: {selected_fund.duration}
👥 Members: {selected_fund.members}
🔄 Renewal: Every {selected_fund.renewal_cycle}
        """
        
        print("=" * 50)
        print("SIMULATED WHATSAPP MESSAGE:")
        print(whatsapp_message)
        print("=" * 50)
        
        # Store selection in session
        session['selected_fund_id'] = fund_id
        session['registration_id'] = registration.id
        
        return redirect(url_for('success'))
        
    except ValueError:
        flash('Invalid fund selection', 'error')
        return redirect(url_for('chit_funds'))

@app.route('/success')
def success():
    """Success page after fund selection"""
    if 'phone_number' not in session or not session.get('otp_verified'):
        return redirect(url_for('login'))
    
    selected_fund_id = session.get('selected_fund_id')
    registration_id = session.get('registration_id')
    
    if not selected_fund_id or not registration_id:
        return redirect(url_for('chit_funds'))
    
    selected_fund = ChitFund.query.get(selected_fund_id)
    registration = ChitFundRegistration.query.get(registration_id)
    
    if not selected_fund or not registration:
        return redirect(url_for('chit_funds'))
    
    return render_template('success.html', 
                         fund=selected_fund, 
                         registration=registration,
                         phone_number=session['phone_number'])

@app.route('/dashboard')
def dashboard():
    """User dashboard showing their registrations"""
    if 'phone_number' not in session or not session.get('otp_verified'):
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    user = User.query.get(user_id)
    
    # Get user's registrations
    registrations = ChitFundRegistration.query.filter_by(user_id=user_id).all()
    
    return render_template('dashboard.html', 
                         user=user,
                         registrations=registrations)

@app.route('/company-info')
def company_info():
    """Display company information"""
    # This would typically come from database or config
    company = {
        'name': 'Your Chit Fund Company',
        'registration': 'REG/2024/XXXXXX',
        'gst': '24XXXXXXXXXXXXXXX',
        'website': 'www.yourcompany.com',
        'phone': '+91 XXXXXXXXXX',
        'whatsapp': '+91 XXXXXXXXXX',
        'email': 'info@yourcompany.com',
        'address': 'Your complete business address with city, state, and pincode',
        'about': 'We are a trusted chit fund company providing reliable financial services to help you achieve your savings goals. Our transparent processes and customer-first approach ensure your financial security.'
    }
    return render_template('company_info.html', company=company)

@app.route('/logout')
def logout():
    """Logout and clear session"""
    session.clear()
    flash('You have been logged out successfully', 'info')
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
