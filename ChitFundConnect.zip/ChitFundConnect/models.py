from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    phone_number = db.Column(db.String(10), unique=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationship with registrations
    registrations = db.relationship('ChitFundRegistration', backref='user', lazy=True)
    
    def __repr__(self):
        return f'<User {self.phone_number}>'

class ChitFund(db.Model):
    __tablename__ = 'chit_funds'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    amount = db.Column(db.Integer, nullable=False)
    duration = db.Column(db.String(50), nullable=False)
    members = db.Column(db.Integer, nullable=False)
    renewal_cycle = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationship with registrations
    registrations = db.relationship('ChitFundRegistration', backref='chit_fund', lazy=True)
    
    def __repr__(self):
        return f'<ChitFund {self.name}>'

class ChitFundRegistration(db.Model):
    __tablename__ = 'chit_fund_registrations'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    chit_fund_id = db.Column(db.Integer, db.ForeignKey('chit_funds.id'), nullable=False)
    registration_date = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='pending')  # pending, approved, rejected
    whatsapp_sent = db.Column(db.Boolean, default=False)
    
    def __repr__(self):
        return f'<Registration {self.user_id} - {self.chit_fund_id}>'

class OTPLog(db.Model):
    __tablename__ = 'otp_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    phone_number = db.Column(db.String(10), nullable=False)
    otp_sent = db.Column(db.String(4), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    verified = db.Column(db.Boolean, default=False)
    verified_at = db.Column(db.DateTime)
    
    def __repr__(self):
        return f'<OTPLog {self.phone_number}>'